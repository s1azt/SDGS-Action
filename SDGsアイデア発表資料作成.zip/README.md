
  # SDGsアイデア発表資料作成

  This is a code bundle for SDGsアイデア発表資料作成. The original project is available at https://www.figma.com/design/9FBl2TuVyAfTHwKGBWtZh1/SDGs%E3%82%A2%E3%82%A4%E3%83%87%E3%82%A2%E7%99%BA%E8%A1%A8%E8%B3%87%E6%96%99%E4%BD%9C%E6%88%90.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  